package com.itcast.mapper;

import com.itcast.domain.Classes;

import java.util.List;

public interface ClassesMapper {
    public abstract List<Classes> findAll();
}
